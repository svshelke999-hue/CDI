"""
File processing utilities for reading medical charts.
"""

import os
from pathlib import Path
from typing import Optional

try:
    from PyPDF2 import PdfReader
except ImportError:
    raise ImportError("Please install PyPDF2: pip install PyPDF2")

try:
    from docx import Document
except ImportError:
    Document = None


class FileProcessor:
    """Handles reading and processing of medical chart files."""
    
    @staticmethod
    def read_chart(file_path: str) -> str:
        """
        Read chart text from .txt, .pdf, or .docx file.
        
        Args:
            file_path: Path to the medical chart file
            
        Returns:
            Extracted text content
            
        Raises:
            ValueError: If file format is unsupported
        """
        ext = Path(file_path).suffix.lower()
        
        if ext == ".txt":
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                return f.read()
        elif ext == ".pdf":
            reader = PdfReader(file_path)
            text = []
            for page in reader.pages:
                text.append(page.extract_text() or "")
            return "\n".join(text)
        elif ext in [".docx", ".doc"]:
            if Document is None:
                raise ImportError("Please install python-docx: pip install python-docx")
            doc = Document(file_path)
            text = []
            for paragraph in doc.paragraphs:
                text.append(paragraph.text)
            return "\n".join(text)
        else:
            raise ValueError("Unsupported file format. Use .txt, .pdf, or .docx")
    
    @staticmethod
    def add_line_numbers(text: str) -> str:
        """
        Add line numbers to text for better reference in compliance evaluation.
        
        Args:
            text: Input text
            
        Returns:
            Text with line numbers prefixed (L001:, L002:, etc.)
        """
        lines = text.split('\n')
        numbered_lines = []
        for i, line in enumerate(lines, 1):
            numbered_lines.append(f"L{i:03d}: {line}")
        return '\n'.join(numbered_lines)
    
    @staticmethod
    def remove_line_numbers(text: str) -> str:
        """
        Remove line numbers from text (e.g., L001:, L002:, etc.).
        
        Args:
            text: Input text that may contain line numbers
            
        Returns:
            Text with line numbers removed
        """
        import re
        # Pattern to match line numbers like L001:, L002:, etc. at the start of lines
        pattern = r'^L\d{3}:\s*'
        lines = text.split('\n')
        cleaned_lines = []
        for line in lines:
            cleaned_line = re.sub(pattern, '', line)
            cleaned_lines.append(cleaned_line)
        return '\n'.join(cleaned_lines)
    
    @staticmethod
    def get_files_to_process(input_dir: str) -> list:
        """
        Get list of files to process from input directory.
        
        Args:
            input_dir: Directory containing medical chart files
            
        Returns:
            List of file paths to process
        """
        files_to_process = []
        
        if not os.path.exists(input_dir):
            print(f"⚠️ Input directory does not exist: {input_dir}")
            return files_to_process
        
        for file in os.listdir(input_dir):
            if file.endswith((".txt", ".pdf", ".docx", ".doc")):
                files_to_process.append(os.path.join(input_dir, file))
        
        return files_to_process
    
    @staticmethod
    def validate_file(file_path: str) -> bool:
        """
        Validate that file exists and is readable.
        
        Args:
            file_path: Path to file to validate
            
        Returns:
            True if file is valid, False otherwise
        """
        if not os.path.exists(file_path):
            print(f"❌ File does not exist: {file_path}")
            return False
        
        if not os.access(file_path, os.R_OK):
            print(f"❌ File is not readable: {file_path}")
            return False
        
        ext = Path(file_path).suffix.lower()
        if ext not in [".txt", ".pdf", ".docx", ".doc"]:
            print(f"❌ Unsupported file format: {ext}")
            return False
        
        return True
